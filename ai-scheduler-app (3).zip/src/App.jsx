
export default function App() {
  return <div>Hello from AI Scheduler</div>;
}
