
import React, { useState, useEffect } from "react";

const crewMemory = [
  { name: "Anthony", role: "Journeyman", skills: ["panel wiring", "lighting control"], experience: 8, status: "active", available: true, hoursYesterday: 7 },
  { name: "Marcus", role: "Apprentice", skills: ["conduit bending", "cleanup"], experience: 2, status: "active", available: true, hoursYesterday: 5 },
  { name: "Derek", role: "Journeyman", skills: ["fire alarm", "rough-in"], experience: 10, status: "active", available: true, hoursYesterday: 6 },
  { name: "Shawn", role: "Foreman", skills: ["supervision", "material planning"], experience: 16, status: "active", available: true, hoursYesterday: 8 },
  { name: "Isaiah", role: "Apprentice", skills: ["pulling wire", "equipment staging"], experience: 1, status: "active", available: true, hoursYesterday: 4 },
  { name: "Leo", role: "Journeyman", skills: ["trim out", "device install"], experience: 5, status: "active", available: true, hoursYesterday: 6 },
  { name: "John", role: "Journeyman", skills: ["rough-in", "MC cable", "gear install"], experience: 7, status: "active", available: true, hoursYesterday: 8 },
  { name: "Paul", role: "Journeyman", skills: ["trim", "lighting controls", "VAV wiring"], experience: 9, status: "active", available: true, hoursYesterday: 6 },
  { name: "Gary", role: "Foreman", skills: ["feeders", "gear coordination", "site planning"], experience: 15, status: "active", available: true, hoursYesterday: 7 },
  { name: "Blake", role: "Journeyman", skills: ["branch circuits", "box layout", "device install"], experience: 6, status: "active", available: false, hoursYesterday: 10 },
  { name: "Trevor", role: "Apprentice", skills: ["material runs", "tool setup"], experience: 1, status: "active", available: true, hoursYesterday: 4 },
  { name: "Eric", role: "Foreman", skills: ["crew coordination", "schedule planning"], experience: 14, status: "active", available: true, hoursYesterday: 6 }
];

export default function App() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">AI Scheduler App</h1>
      <p>This is your full app code restored and ready for deployment. Add more inputs and logic as needed.</p>
    </div>
  );
}
